-- Databricks notebook source
SELECT current_database()

-- COMMAND ----------

SHOW DATABASES

-- COMMAND ----------

