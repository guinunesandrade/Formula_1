# Databricks notebook source
dbutils.widgets.text('p_file_date', '2021-03-21')
v_file_date = dbutils.widgets.get('p_file_date')

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

from pyspark.sql.functions import col, current_timestamp

# COMMAND ----------

drivers_df = spark.read.format('delta').load(f'{processed_folder_path}/drivers').withColumnRenamed('name', 'pilot')

# COMMAND ----------

constructors_df = spark.read.format('delta').load(f'{processed_folder_path}/constructors').withColumnRenamed('name', 'team')

# COMMAND ----------

results_df = spark.read.format('delta').load(f'{processed_folder_path}/results') \
.filter(f"file_date = '{v_file_date}'") \
.withColumnRenamed('time', 'race_time') 

# COMMAND ----------

races_df = spark.read.format('delta').load(f'{processed_folder_path}/races').withColumnRenamed('name', 'race_name') \
                                                              .withColumnRenamed('race_timestamp', 'race_date')

# COMMAND ----------

circuits_df = spark.read.format('delta').load(f'{processed_folder_path}/circuits').withColumnRenamed('name', 'circuit_name')

# COMMAND ----------

final_df = drivers_df.join(results_df, drivers_df.driver_id == results_df.driver_id, 'inner') \
                     .join(constructors_df, results_df.constructor_id == constructors_df.constructor_id, 'inner') \
                     .join(races_df, results_df.race_id == races_df.race_id, 'inner') \
                     .join(circuits_df, races_df.circuit_id == circuits_df.circuit_id, 'inner') \
                     .select(results_df.race_id, col('pilot'), drivers_df.number, drivers_df.nationality, col('team'), col('grid'),
                             col('fastest_lap'), col('race_time'), col('points'), col('position'), col('race_date'), col('race_year'),
                             col('circuit_name'), results_df.file_date) \
                     .withColumn('created_date', current_timestamp())                    

# COMMAND ----------

display(final_df)

# COMMAND ----------

merge_condition = 'tgt.pilot = src.pilot AND tgt.race_id = src.race_id'
merge_delta_data(final_df, 'f1_presentation', 'race_results', presentation_folder_path, merge_condition, 'race_id')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT race_id, COUNT(*) 
# MAGIC   FROM f1_presentation.race_results
# MAGIC   GROUP BY 1
# MAGIC   ORDER BY 1 DESC;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_presentation.race_results