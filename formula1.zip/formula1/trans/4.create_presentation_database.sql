-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS f1_presentation
LOCATION "/mnt/projetoformula1/presentation"

-- COMMAND ----------

DESCRIBE DATABASE f1_presentation

-- COMMAND ----------

