-- Databricks notebook source
CREATE OR REPLACE TEMP VIEW v_dominant_constructors
AS
SELECT team_name, 
       count(1) AS total_races, 
       sum(calculated_points) AS total_points,
       round(avg(calculated_points), 2) AS avg_points,
       RANK() OVER(ORDER BY avg(calculated_points) DESC) team_rank
  FROM f1_presentation.calculated_race_results
  GROUP BY team_name
  HAVING total_races >= 100
  ORDER BY avg_points DESC

-- COMMAND ----------

SELECT * FROM v_dominant_constructors

-- COMMAND ----------

SELECT race_year,
       team_name, 
       count(1) AS total_races, 
       sum(calculated_points) AS total_points,
       round(avg(calculated_points), 2) AS avg_points      
  FROM f1_presentation.calculated_race_results
  WHERE team_name IN (SELECT team_name FROM v_dominant_constructors WHERE team_rank <= 10 )
  GROUP BY race_year, team_name
  ORDER BY race_year, avg_points DESC

-- COMMAND ----------

SELECT race_year,
       team_name, 
       count(1) AS total_races, 
       sum(calculated_points) AS total_points,
       round(avg(calculated_points), 2) AS avg_points      
  FROM f1_presentation.calculated_race_results
  WHERE team_name IN (SELECT team_name FROM v_dominant_constructors WHERE team_rank <= 10 )
  GROUP BY race_year, team_name
  ORDER BY race_year, avg_points DESC

-- COMMAND ----------

SELECT race_year,
       team_name, 
       count(1) AS total_races, 
       sum(calculated_points) AS total_points,
       round(avg(calculated_points), 2) AS avg_points      
  FROM f1_presentation.calculated_race_results
  WHERE team_name IN (SELECT team_name FROM v_dominant_constructors WHERE team_rank <= 10 )
  GROUP BY race_year, team_name
  ORDER BY race_year, avg_points DESC

-- COMMAND ----------

