-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS f1_raw;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Creating circuits table
-- MAGIC * CSV file

-- COMMAND ----------

DROP TABLE IF EXISTS f1_raw.circuits;
CREATE TABLE IF NOT EXISTS f1_raw.circuits
(circuitId INT,
 circuitRef STRING,
 name STRING,
 location STRING,
 country STRING,
 lat DOUBLE,
 alt DOUBLE,
 url STRING)
 USING csv
 OPTIONS (path '/mnt/projetoformula1/raw/circuits.csv', header TRUE);

-- COMMAND ----------

SELECT * FROM f1_raw.circuits

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Creating races table
-- MAGIC * CSV file

-- COMMAND ----------

DROP TABLE IF EXISTS f1_raw.races;
CREATE TABLE IF NOT EXISTS f1_raw.races
(raceID INT,
 year INT,
 round INT,
 circuitID INT,
 name STRING,
 date DATE,
 time STRING,
 url STRING)
 USING csv
 OPTIONS (path '/mnt/projetoformula1/raw/races.csv', header TRUE);

-- COMMAND ----------

SELECT * FROM f1_raw.races

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Creating constructors table  
-- MAGIC * Single line JSON  
-- MAGIC * Simple structure

-- COMMAND ----------

DROP TABLE IF EXISTS f1_raw.constructors;
CREATE TABLE IF NOT EXISTS f1_raw.constructors
(constructorId INT,
 constructorRef STRING,
 name STRING,
 nationality STRING,
 url STRING)
 USING json
 OPTIONS (path '/mnt/projetoformula1/raw/constructors.json');

-- COMMAND ----------

SELECT * FROM f1_raw.constructors

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Creating drivers table  
-- MAGIC * Single line JSON  
-- MAGIC * Complex structure

-- COMMAND ----------

DROP TABLE IF EXISTS f1_raw.drivers;
CREATE TABLE IF NOT EXISTS f1_raw.drivers
(driverId INT,
driverRef STRING,
number INT,
code STRING,
name STRUCT<forename: STRING, surname: STRING>,
dob DATE,
nationality STRING,
url STRING)
USING json
OPTIONS (path '/mnt/projetoformula1/raw/drivers.json');

-- COMMAND ----------

SELECT * FROM f1_raw.drivers

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Creating results table  
-- MAGIC * Single line JSON  
-- MAGIC * Simple structure

-- COMMAND ----------

DROP TABLE IF EXISTS f1_raw.results;
CREATE TABLE IF NOT EXISTS f1_raw.results
(resultId INT,
raceId INT,
driverId INT,
constructorId INT,
number INT,
grid INT,
position INT,
positionText STRING,
positionOrder INT,
points DOUBLE,
laps INT,
time STRING,
milliseconds INT,
fastestLap INT,
rank INT,
fastestLapTime STRING,
fastestLapSpeed STRING,
statusId INT)
USING json
OPTIONS (path '/mnt/projetoformula1/raw/results.json');

-- COMMAND ----------

SELECT * FROM f1_raw.results

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Creating results table  
-- MAGIC * Multi line JSON  
-- MAGIC * Simple structure

-- COMMAND ----------

DROP TABLE IF EXISTS f1_raw.pit_stops;
CREATE TABLE IF NOT EXISTS f1_raw.pit_stops
(raceId INT,
driverId INT,
stop STRING,
lap INT,
time STRING,
duration STRING,
milliseconds INT)
USING json
OPTIONS (path '/mnt/projetoformula1/raw/pit_stops.json', multiline TRUE);

-- COMMAND ----------

SELECT * FROM f1_raw.pit_stops

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Creating tables for list of files

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Creating Lap Times table
-- MAGIC * CSV file
-- MAGIC * Multiple files

-- COMMAND ----------

DROP TABLE IF EXISTS f1_raw.lap_times;
CREATE TABLE IF NOT EXISTS f1_raw.lap_times
(raceId INT,
driverId INT,
lap INT,
position INT,
time STRING,
milliseconds INT)
USING csv
OPTIONS (path '/mnt/projetoformula1/raw/lap_times/');

-- COMMAND ----------

SELECT * FROM f1_raw.lap_times

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Creating Qualifying table
-- MAGIC * JSON file
-- MAGIC * Multiline JSON
-- MAGIC * Multiple files

-- COMMAND ----------

DROP TABLE IF EXISTS f1_raw.qualifying;
CREATE TABLE IF NOT EXISTS f1_raw.qualifying
(qualifyId INT,
raceId INT,
driverId INT,
constructorId INT,
number INT,
position INT,
q1 STRING,
q2 STRING,
q3 STRING)
USING json
OPTIONS (path '/mnt/projetoformula1/raw/qualifying/', multiline TRUE)

-- COMMAND ----------

SELECT * FROM f1_raw.qualifying

-- COMMAND ----------

DESCRIBE EXTENDED f1_raw.qualifying

-- COMMAND ----------

