# Databricks notebook source
raw_folder_path = '/mnt/projetoformula1/raw'
processed_folder_path = '/mnt/projetoformula1/processed'
presentation_folder_path = '/mnt/projetoformula1/presentation'