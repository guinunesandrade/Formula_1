# Databricks notebook source
# MAGIC %md
# MAGIC ### Ingesting races.csv file

# COMMAND ----------

dbutils.widgets.text('p_data_source', '')
v_data_source = dbutils.widgets.get('p_data_source')

# COMMAND ----------

dbutils.widgets.text('p_file_date', '2021-03-21')
v_file_date = dbutils.widgets.get('p_file_date')

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1 - Reading the CSV file using spark dataframe reader API

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Identifying the mounts

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Listing the files contained inside the container "raw" and copying the races.csv path

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/projetoformula1/raw 

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Step 2: Defining our dataframe schema for when we read the "circuits.csv" file

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DateType

# COMMAND ----------

races_schema = StructType([StructField('raceID', IntegerType(), False),
                           StructField('year', IntegerType(), True),
                           StructField('round', IntegerType(), True),
                           StructField('circuitID', IntegerType(), False),
                           StructField('name', StringType(), True),
                           StructField('date', DateType(), True),
                           StructField('time', StringType(), True),
                           StructField('url', StringType(), True)
                           ])

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Reading the "races.csv" file with the new schema

# COMMAND ----------

races_df = spark.read.csv(f'{raw_folder_path}/{v_file_date}/races.csv', header=True, schema=races_schema)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Printing the new dataframe schema 

# COMMAND ----------

races_df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 3: Selecting only the required columns to rename them

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Creating new columns 

# COMMAND ----------

from pyspark.sql.functions import to_timestamp, concat, col, lit

# COMMAND ----------

races_df = races_df.withColumn('race_timestamp', to_timestamp(concat(col('date'), lit(' '), col('time')), 'yyyy-MM-dd HH:mm:ss')) 

# COMMAND ----------

races_selected_df = races_df.select(col('raceId'), col('year'), col('round'), 
                                    col('circuitID'), col('name'), col('race_timestamp'))

# COMMAND ----------

display(races_selected_df)
races_selected_df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Renaming the columns as required and adding new ones

# COMMAND ----------

races_renamed_df = races_selected_df.withColumnRenamed(existing='raceID', new='race_id')\
                                    .withColumnRenamed(existing='year', new='race_year')\
                                    .withColumnRenamed(existing='circuitID', new='circuit_id') \
                                    .withColumn('data_source', lit(v_data_source)) \
                                    .withColumn('file_date', lit(v_file_date))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 4: Adding ingestion date to the dataframe

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

races_final_df = add_ingestion_date(races_renamed_df)

# COMMAND ----------

display(races_final_df)
races_final_df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 5: Writing data partitioning by the "race_year" column to data lake and verifyng if it's been saved correctly

# COMMAND ----------

races_final_df.write.mode('overwrite').partitionBy('race_year').format('delta').saveAsTable('f1_processed.races')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_processed.races

# COMMAND ----------

dbutils.notebook.exit('Success')