# Databricks notebook source
dbutils.widgets.text('p_data_source', '')
v_data_source = dbutils.widgets.get('p_data_source')

# COMMAND ----------

dbutils.widgets.text('p_file_date', '2021-03-21')
v_file_date = dbutils.widgets.get('p_file_date')

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1 - Reading the "construnctors.JSON" file using the spark dataframe reader API

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Defining the schema using DDL-formatted string instead of "pyspark.sql.types.StructType" object

# COMMAND ----------

constructors_schema = 'constructorId INTEGER NOT NULL, constructorRef STRING, name STRING, nationality STRING, url STRING' 

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Seeing where the "constructors.json" file is located, i.e, its path

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/projetoformula1/raw

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Reading the "construnctors.JSON" file

# COMMAND ----------

constructors_df = spark.read.json(f'{raw_folder_path}/{v_file_date}/constructors.json', schema=constructors_schema)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Verifying if it's all ok

# COMMAND ----------

display (constructors_df)
constructors_df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ####Step 2 - Dropping the "url" column from the dataframe

# COMMAND ----------

from pyspark.sql.functions import col

# COMMAND ----------

constructors_df = constructors_df.drop(col("url")) 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 3 - Renaming some columns

# COMMAND ----------

c = 0
old_columns = ['constructorID', 'constructorRef']
columns_renamed = ['constructor_id', 'constructor_ref']
for old_column in old_columns:
    constructors_df = constructors_df.withColumnRenamed(old_column, columns_renamed[c])
    c += 1
constructors_renamed_df = constructors_df
constructors_renamed_df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 4 - Adding new columns

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, lit

# COMMAND ----------

constructors_final_df = add_ingestion_date(constructors_renamed_df)
constructors_final_df = constructors_final_df.withColumn('data_source', lit(v_data_source)) \
                                             .withColumn('file_date', lit(v_file_date))

# COMMAND ----------

display(constructors_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 5 - Writing the output to parquet file

# COMMAND ----------

constructors_final_df.write.mode('overwrite').format('delta').saveAsTable('f1_processed.constructors')

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Verifying if it's been saved correctly

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_processed.constructors

# COMMAND ----------

dbutils.notebook.exit('Success')